package sanctuary;

/**
 * Enumeration class to store the favorite food a monkey.
 */
public enum Food {
  eggs, fruits, insects, leaves, nuts, seeds, treeSap
}
