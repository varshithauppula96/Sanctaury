package sanctuary;

/**
 * Enumeration class to store the sex of a monkey as either female or male.
 */
public enum Sex {
  Male, Female
}
