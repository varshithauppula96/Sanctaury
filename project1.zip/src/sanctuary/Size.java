package sanctuary;

/**
 * Enumeration class to store the size of a monkey as either small, medium or larger.
 */
public enum Size {
  small, medium, large
}
