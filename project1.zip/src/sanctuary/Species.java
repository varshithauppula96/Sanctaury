package sanctuary;

/**
 * Enumeration class to store the various species of the Jungle Friends Primate Sanctuary.
 */
public enum Species {
  drill, guereza, howler, mangabey, saki, spider, squirrel, tamarin
}
